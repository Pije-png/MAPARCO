<?php
include '../../connection.php';

// Fetch all orders with customer names and product details
$sql = "SELECT o.OrderID, o.OrderDate, o.TotalAmount, o.OrderStatus, c.Name AS CustomerName,
               p.ProductName, p.Photo
        FROM orders o
        JOIN customers c ON o.CustomerID = c.CustomerID
        JOIN orderitems oi ON o.OrderID = oi.OrderID
        JOIN products p ON oi.ProductID = p.ProductID
        ORDER BY o.OrderDate DESC";

$result = $conn->query($sql);

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order History</title>
    <link rel="stylesheet" href="styles.css"> <!-- Include your CSS file for styling -->
</head>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }

    .container {
        max-width: 1200px;
        margin: 20px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .home {
        padding: 20px;
        background-color: #ffffff;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    table {
        width: 100%;
    }

    .table {
        background: var(--body-color);
        box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.1);
        transition: all 0.1s ease-in-out;
        min-height: 530px;
    }

    .table th {
        text-align: left;
        width: 12%;
        padding: 10px;
        background-color: #8fd19e;
    }

    tr,
    td {
        border-collapse: collapse;
        padding: 0 10px;
        margin: 0;
        font-size: 12px;
    }

    tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    tr:hover {
        background-color: #f1f1f1;
    }

    td img {
        max-width: 50px;
        height: auto;
        border-radius: 4px;
    }

    .orders-table-container {
        max-height: 450px;
        min-height: 450px;
        width: 100%;
        scrollbar-width: thin;
    }
</style>

<body>
    <?php include 'sidebar.php'; ?>
    <?php include '../graph.php'; ?>

    <section class="home">
        <div class="table container-fluid bg bg-success p-1">
            <div class="HLRhQ8">
                <h3 class="fw-bold fs-4 my-3">Order History</h3>
            </div>
            <div class="">
                <div style="overflow-x:auto;" class="orders-table-container col-12">
                    <table>
                        <thead>
                            <tr>
                                <!-- <th>Order ID</th> -->
                                <th>Order Date</th>
                                <th>Customer Name</th>
                                <th>Total Amount</th>
                                <th>Order Status</th>
                                <th>Product Name</th>
                                <th>Product Photo</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $result->fetch_assoc()) : ?>
                                <tr>
                                    <!-- <td><?php echo $row['OrderID']; ?></td> -->
                                    <td><?php echo date("F j, Y", strtotime($row['OrderDate'])); ?></td>
                                    <td><?php echo $row['CustomerName']; ?></td>
                                    <td class="text-danger">₱<?php echo $row['TotalAmount']; ?></td>
                                    <td>
                                        <?php
                                        switch ($row['OrderStatus']) {
                                            case 'Pending':
                                                echo '<button class="btn btn-primary btn-sm" disabled>Pending</button>';
                                                break;
                                            case 'Processing':
                                                echo '<button class="btn btn-primary btn-sm" disabled>Processing</button>';
                                                break;
                                            case 'Shipped':
                                                echo '<button class="btn btn-info btn-sm" disabled>Shipping</button>';
                                                break;
                                            case 'Delivered':
                                                echo '<button class="btn btn-success btn-sm" disabled>Delivered</button>';
                                                break;
                                            case 'Cancelled':
                                                echo '<button class="btn btn-secondary btn-sm" disabled>Cancelled</button>';
                                                break;
                                            default:
                                                echo '<button class="btn btn-secondary btn-sm" disabled>Unknown Status</button>';
                                                break;
                                        }
                                        ?>
                                    </td>
                                    <td><?php echo $row['ProductName']; ?></td>
                                    <td><img src="<?php echo $row['Photo']; ?>" alt="<?php echo $row['ProductName']; ?>" class="product-image"></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
</body>

</html>