<?php
include '../../connection.php';

// Fetch all reviews with customer names and product details
$sql = "SELECT r.ReviewID, c.Name AS CustomerName, p.ProductName, p.Photo AS ProductPhoto, r.Rating, r.ReviewText, r.ReviewDate
        FROM reviews r
        INNER JOIN customers c ON r.CustomerID = c.CustomerID
        INNER JOIN products p ON r.ProductID = p.ProductID";

$result = $conn->query($sql);

// Find the product with the highest rating
$sqlHighestRating = "SELECT p.ProductName, p.Photo AS ProductPhoto, AVG(r.Rating) AS AverageRating
                     FROM products p
                     INNER JOIN reviews r ON p.ProductID = r.ProductID
                     GROUP BY p.ProductID
                     ORDER BY AverageRating DESC
                     LIMIT 1";
$resultHighestRating = $conn->query($sqlHighestRating);
$rowHighestRating = $resultHighestRating->fetch_assoc();

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reviews</title>
</head>
<style>
    body {
        font-family: 'Poppins', sans-serif;
        background-color: #f8f9fa;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        background-color: #FFF;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
    }

    th,
    td {
        font-size: 12px;
        padding: 12px 15px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    th {
        /* background-color: #15BE2F; */
        /* Amber */
        color: #fff;
        font-size: 14px;
    }

    tbody tr:hover {
        background-color: #FFF3E0;
        /* Light Orange */
    }

    .product-image {
        max-width: 50px;
        height: auto;
        border-radius: 6px;
    }

    .product-photo img {
        max-width: 150px;
        height: auto;
    }

    .highest-rating {
        text-align: center;
    }

    .product-info {
        display: inline-block;
        background-color: #15BE2F;
        /* Green */
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .product-details p {
        font-size: 18px;
        margin: 8px 0;
        color: #fff;
    }

    .crown {
        color: gold;
    }
</style>

<body>
    <?php include 'sidebar.php'; ?>
    <?php include '../graph.php'; ?>

    <section class="home">
        <div class="container">
            <div class="highest-rating pt-3">
                <h2 class="mt-0">Product with the Highest Rating</h2>
                <div class="product-info">
                    <div class="product-photo">
                        <img src="<?php echo $rowHighestRating['ProductPhoto']; ?>" alt="<?php echo $rowHighestRating['ProductName']; ?>" class="product-image">
                    </div>
                    <div class="product-details">
                        <p><strong>Product Name:</strong> <?php echo $rowHighestRating['ProductName']; ?></p>
                        <p><strong>Average Rating:</strong> <?php echo number_format($rowHighestRating['AverageRating'], 2); ?>
                            <i class="fas fa-crown crown"></i>
                        </p>
                    </div>
                </div>
            </div>
            <div class="reviews-container">
                <div class="HLRhQ8 mb-0">
                    <h3 class="mt-3 fw-bold text-success">Reviews</h3>
                </div>
                <div class="table container-fluid bg bg-success">
                    <div style="overflow-x:auto;" class="scrollpsy col-12 p-2">
                        <table>
                            <thead class="bg bg-success">
                                <tr>
                                    <!-- <th>Review ID</th> -->
                                    <th>Customer Name</th>
                                    <th>Product Name</th>
                                    <th>Product Photo</th>
                                    <th>Rating</th>
                                    <th>Review Text</th>
                                    <th>Review Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $result->fetch_assoc()) : ?>
                                    <tr>
                                        <!-- <td><?php echo $row['ReviewID']; ?></td> -->
                                        <td><?php echo $row['CustomerName']; ?></td>
                                        <td><?php echo $row['ProductName']; ?></td>
                                        <td><img src="<?php echo $row['ProductPhoto']; ?>" alt="<?php echo $row['ProductName']; ?>" class="product-image"></td>
                                        <td><?php echo $row['Rating']; ?>⭐</td>
                                        <td><?php echo $row['ReviewText']; ?></td>
                                        <td><?php echo date("F j, Y", strtotime($row['ReviewDate'])); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    </section>
    <style>
        .HLRhQ8 {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .table-container {
            min-height: auto;
            overflow-y: auto;
            scrollbar-width: thin;
        }

        .admin-dashboard {
            width: 100%;
            border-bottom: 1px solid #dee2e6;
            border-collapse: collapse;
            margin-bottom: 0;
        }
    </style>
</body>

</html>