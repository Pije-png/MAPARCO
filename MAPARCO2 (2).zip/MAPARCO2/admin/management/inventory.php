<?php
include '../../connection.php'; // Include your database connection file

// Fetch products from the database
$query = "SELECT * FROM products";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <title>Inventory</title>
</head>
<style>
    .img {
        max-width: 50px;
        object-fit: contain;
    }

    .home {
        padding: 20px;
        background-color: #ffffff;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .table th {
        text-align: left;
        padding: 10px;
        background-color: #8fd19e;
    }
    table{
        width: 100%;
    }

    tr,
    td {
        border-collapse: collapse;
        padding: 0 10px;
        margin: 0;
        font-size: 12px;
    }
    tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    tr:hover {
        background-color: #f1f1f1;
    }

    .bg.bg-light td {
        padding: 10px;
    }

    .table {
        background: var(--body-color);
        box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.1);
        transition: all 0.1s ease-in-out;
        min-height: 530px;
    }

    .orders-table-container {
        max-height: 450px;
        min-height: 450px;
        scrollbar-width: thin;
    }

    .admin-dashboard {
        width: 100%;
        border-bottom: 1px solid #dee2e6;
        border-collapse: collapse;
        border-top: 1px solid #dee2e6;
        margin-bottom: 0;
    }
</style>

<body>
    <?php include 'sidebar.php'; ?>
    <?php include '../graph.php'; ?>

    <section class="home">
        <div class="table container-fluid bg bg-success p-1">
            <div class="HLRhQ8">
                <h3 class="fw-bold fs-4 my-3">Product Invertory</h3>
            </div>
            <div class="">
                <div style="overflow-x:auto;" class="orders-table-container col-12">
                    <table>
                        <thead>
                            <tr>
                                <th>Product ID</th>
                                <th>Product Name</th>
                                <th>Photo</th>
                                <th>Description</th>
                                <th>Price</th>
                                <th>Stocks</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($result->num_rows > 0) {
                                // Output data of each row
                                while ($row = $result->fetch_assoc()) {
                                    echo "<tr>";
                                    echo "<td>" . $row['ProductID'] . "</td>";
                                    echo "<td>" . $row['ProductName'] . "</td>";
                                    echo "<td><img src='" . $row['Photo'] . "' alt='Product Image' style='width:50px;height:50px;'></td>";
                                    echo "<td>" . $row['Description'] . "</td>";
                                    echo "<td class='text-danger'>₱" . $row['Price'] . "</td>";
                                    echo "<td class='text-primary'>" . $row['QuantityAvailable'] . "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='8'>No products found</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
</body>

</html>

<?php
$conn->close();
?>