<?php
include '../../../connection.php';

// Update order status
if (isset($_POST['update_status'])) {
    if (isset($_POST['new_order_status']) && !empty($_POST['new_order_status'])) {
        $orderID = $_POST['order_id'];
        $newOrderStatus = $_POST['new_order_status'];

        // Update order status in the database
        $update_status_sql = "UPDATE orders SET OrderStatus = '$newOrderStatus' WHERE OrderID = '$orderID'";
        if ($conn->query($update_status_sql) === TRUE) {
            $order_status_message = "Order status updated successfully!";
        } else {
            $order_status_message = "Error updating order status: " . $conn->error;
        }
    } else {
        $order_status_message = "Note: Please select a new order status!";
    }
}

// Update payment status
if (isset($_POST['update_payment_status'])) {
    if (isset($_POST['new_payment_status']) && !empty($_POST['new_payment_status'])) {
        $orderID = $_POST['order_id'];
        $newPaymentStatus = $_POST['new_payment_status'];

        // Update payment status in the database
        $update_payment_status_sql = "UPDATE orders SET PaymentStatus = '$newPaymentStatus' WHERE OrderID = '$orderID'";
        if ($conn->query($update_payment_status_sql) === TRUE) {
            $payment_status_message = "Payment status updated successfully!";
        } else {
            $payment_status_message = "Error updating payment status: " . $conn->error;
        }
    } else {
        $payment_status_message = "Note: Please select a new payment status!";
    }
}

// SQL query to fetch only pending orders data with customer names and addresses
$sql = "SELECT o.*, a.FullName AS CustomerName, a.Description, a.HouseNo, a.Street, a.Barangay, a.City, a.Province, a.ZipCode 
        FROM orders o 
        JOIN addresses a ON o.AddressID = a.AddressID
        WHERE o.OrderStatus = 'Pending'";
$result = $conn->query($sql);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Orders.css">
    <title>Orders</title>
</head>

<body>
    <?php include 'sidebar-orders.php'; ?>
    <?php include '../../graph.php'; ?>
    <section class="home">
        <div class="order-container">
            <div class="table pending-container container-fluid bg bg-success">
            <div class="HLRhQ8 column">
                    <h3 class="fw-bold">Pending</h3>
                    <div class="status-messages">
                        <?php if (isset($order_status_message)) {
                            echo "<div class='status-message border border-1 text-success fw-bold'>$order_status_message</div>";
                        } ?>
                        <?php if (isset($payment_status_message)) {
                            echo "<div class='status-message border border-1 text-success fw-bold'>$payment_status_message</div>";
                        } ?>
                    </div>
                </div>
                <div class="orders-table-container bg bg-light">
                    <div class="header-container">
                        <table class="admin-dashboard">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Order Date</th>
                                    <th>Total Amount</th>
                                    <th>Order Status</th>
                                    <th>Payment Status</th>
                                    <th>Shipping Address</th>
                                    <th>ORDER</th>
                                    <th>PAYMENT</th>
                                    <th>Generate QR Code</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo "<tr>";
                                    echo "<td>" . $row["CustomerName"] . "</td>";
                                    echo "<td>" . date("F j, Y", strtotime($row["OrderDate"])) . "</td>";
                                    echo "<td class='TotalAmount'>₱" . $row["TotalAmount"] . "</td>";
                                    echo "<td class='order-status-" . strtolower(str_replace(' ', '-', $row["OrderStatus"])) . "'>" . $row["OrderStatus"] . "</td>";
                                    // echo "<td>";
                                    // switch ($row['OrderStatus']) {
                                    //     case 'Pending':
                                    //         echo '<button class="btn btn-primary btn-sm" disabled>Pending</button>';
                                    //         break;
                                    //     case 'Processing':
                                    //         echo '<button class="btn btn-primary btn-sm" disabled>Processing</button>';
                                    //         break;
                                    //     case 'Shipped':
                                    //         echo '<button class="btn btn-info btn-sm" disabled>Shipping</button>';
                                    //         break;
                                    //     case 'Delivered':
                                    //         echo '<button class="btn btn-success btn-sm" disabled>Delivered</button>';
                                    //         break;
                                    //     case 'Cancelled':
                                    //         echo '<button class="btn btn-secondary btn-sm" disabled>Cancelled</button>';
                                    //         break;
                                    //     default:
                                    //         echo '<button class="btn btn-secondary btn-sm" disabled>Unknown Status</button>';
                                    //         break;
                                    // }
                                    // echo "</td>";
                                    
                                    echo "<td class='payment-status-" . strtolower(str_replace(' ', '-', $row["PaymentStatus"])) . "'>" . $row["PaymentStatus"] . "</td>";
                                    echo "<td> <button  class='btn btn-outline-primary' onclick='displayShippingAddress(\"" . $row["Description"] . ", " . $row["HouseNo"] . ", " . $row["Street"] . ", " . $row["Barangay"] . ", " . $row["City"] . ", " . $row["Province"] . ", " . $row["ZipCode"] . "\")'>View</button></td>";
                                    echo "<td>";
                                    // Update Order Status Form
                                    echo "<form method='post'>";
                                    echo "<input type='hidden' name='order_id' value='" . $row["OrderID"] . "'>";
                                    echo "<select name='new_order_status' class='form-select form-select-sm'>";
                                    echo "<option value='' disabled selected>Status</option>";
                                    echo "<option value='Pending'>Pending</option>";
                                    echo "<option value='Processing'>Processing</option>";
                                    echo "<option value='Shipped'>Shipped</option>";
                                    echo "<option value='Delivered'>Delivered</option>";
                                    echo "</select>";
                                    echo "<button type='submit' name='update_status' class='btn btn-primary'>Update</button>";
                                    echo "</form>";
                                    echo "</td>";
                                    // Update Payment Status Form
                                    echo "<td>";
                                    echo "<form method='post'>";
                                    echo "<input type='hidden' name='order_id' value='" . $row["OrderID"] . "'>";
                                    echo "<select name='new_payment_status'  class='form-select form-select-sm'>";
                                    echo "<option value='' disabled selected>Status</option>";
                                    echo "<option value='Pending'>Pending</option>";
                                    echo "<option value='Paid'>Paid</option>";
                                    echo "</select>";
                                    echo "<button type='submit' name='update_payment_status'  class='btn btn-primary'>Update</button>";
                                    echo "</form>";
                                    echo "</td>";
                                    echo "<td>";
                                    echo "<button type='button' class='btn btn-primary' onclick='generateQRCode(" . $row["OrderID"] . ")'>Generate QR Code</button>";
                                    echo "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='9'>No orders found</td></tr>";
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Modal HTML -->
            <div id="qrModal" class="modal">
                <div class="modal-content">
                    <span class="close" onclick="closeModal()">&times;</span>
                    <p>Scan this QR Code to mark order as Delivered</p>
                    <div id="qrCodeContainer"></div>
                    <a id="downloadLink" download="QRCode.png">Download QR Code</a>
                </div>
            </div>
            <!-- Modal HTML for Shipping Address -->
            <div id="myModal" class="modal">
                <div class="modal-content">
                <span class="close btn btn-outline-danger ms-auto rounded-0" onclick="closeModal()">&times;</span>
                    <p id="shippingAddressContent"></p>
                </div>
            </div>
        </div>
    </section>

    <script>
        // Function to display modal with shipping address
        function displayShippingAddress(address) {
            var modal = document.getElementById("myModal");
            var addressContent = document.getElementById("shippingAddressContent");
            addressContent.innerHTML = "<strong>Shipping Address:</br></strong> " + address;
            modal.style.display = "block";
        }

        // Function to generate QR code and display in modal
        function generateQRCode(orderID) {
            fetch('generate_qr.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'generate_qr=true&order_id=' + orderID,
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    var qrModal = document.getElementById("qrModal");
                    var qrCodeContainer = document.getElementById("qrCodeContainer");
                    qrCodeContainer.innerHTML = '<img src="' + data.qrImage + '" alt="QR Code">';
                    var downloadLink = document.getElementById("downloadLink");
                    downloadLink.href = data.qrImage;
                    qrModal.style.display = "block";
                } else {
                    alert("Error generating QR code.");
                }
            })
            .catch(error => console.error('Error:', error));
        }

        function closeModal() {
            var qrModal = document.getElementById("qrModal");
            qrModal.style.display = "none";
            var myModal = document.getElementById("myModal");
            myModal.style.display = "none";
        }

        // Close the modal when clicking outside of it
        window.onclick = function(event) {
            var qrModal = document.getElementById("qrModal");
            var myModal = document.getElementById("myModal");
            if (event.target == qrModal || event.target == myModal) {
                qrModal.style.display = "none";
                myModal.style.display = "none";
            }
        }
    </script>
    <script>
        const toggle = document.querySelector(".toggle");
        const sidebar = document.querySelector(".sidebar");
        toggle.addEventListener("click", () => {
            sidebar.classList.toggle("close");
        });
    </script>
</body>

</html>

<?php
// Close the database connection
$conn->close();
?>
