<?php
include '../../connection.php';

// SQL query to fetch customer data
$sql = "SELECT CustomerID, Name, Email, create_on FROM customers";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customers</title>
    <link rel="stylesheet" href="Management.css">
</head>

<body>

    <?php include 'sidebar.php'; ?>
    <?php include '../graph.php'; ?>

    <section class="home">
        <div class="customer-container">
            <div class="table container-fluid bg bg-success">
                <div class="HLRhQ8">
                    <h2 class="fw-bold fs-4 my-3">Registered Users</h2>
                </div>
                <div style="overflow-x:auto;" class="orders-table-container col-12">
                    <table class="admin-dashboard">
                        <thead>
                            <tr>
                                <!-- <th>CustomerID</th> -->
                                <th>Name</th>
                                <th>Email</th>
                                <th>Joined on: </th>
                                <!-- <th>Tools</th> -->
                            </tr>
                        </thead>
                        <tbody class="bg bg-light">
                            <?php
                            if ($result && $result->num_rows > 0) {
                                // Output data of each row
                                while ($row = $result->fetch_assoc()) {
                                    echo "<tr>";
                                    // echo "<td>" . $row["CustomerID"] . "</td>";
                                    echo "<td>" . $row["Name"] . "</td>";
                                    echo "<td>" . $row["Email"] . "</td>";
                                    echo "<td>" . date("F j, Y", strtotime($row["create_on"])) . "</td>";
                                    // echo "<td>";
                                    // echo "<a href='customer_update.php?id=" . $row["CustomerID"] . "'>Update</a> | ";
                                    // echo "<a href='customer_delete.php?id=" . $row["CustomerID"] . "'>Delete</a>";
                                    // echo "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='4'>No customers found</td></tr>";
                            }
                            ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </section>

    <script>
        const toggle = document.querySelector(".toggle");
        const sidebar = document.querySelector(".sidebar");
        toggle.addEventListener("click", () => {
            sidebar.classList.toggle("close");
        });
    </script>
</body>

</html>

<?php
// Close the database connection
$conn->close();
?>