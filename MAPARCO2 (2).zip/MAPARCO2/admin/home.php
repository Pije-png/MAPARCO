<?php
include '../connection.php';

// Calculate total sales across all months
$sql_total_sales = "SELECT SUM(TotalAmount) AS total_sales FROM orders WHERE PaymentStatus = 'Paid'";
$result_total_sales = $conn->query($sql_total_sales);
$row_total_sales = $result_total_sales->fetch_assoc();
$total_sales = $row_total_sales['total_sales'];

$sql_products = "SELECT COUNT(*) AS total_products FROM products";
$result_products = $conn->query($sql_products);
$row_products = $result_products->fetch_assoc();
$total_products = $row_products['total_products'];

$sql_users = "SELECT COUNT(*) AS total_users FROM customers";
$result_users = $conn->query($sql_users);
$row_users = $result_users->fetch_assoc();
$total_users = $row_users['total_users'];

$sql_recent_orders = "SELECT o.*, a.FullName AS CustomerName, a.Description, a.HouseNo, a.Street, a.Barangay, a.City, a.Province, a.ZipCode 
FROM orders o 
JOIN addresses a ON o.AddressID = a.AddressID
ORDER BY o.OrderDate DESC 
LIMIT 10";
$result_recent_orders = $conn->query($sql_recent_orders);

$recent_orders = array();
if ($result_recent_orders->num_rows > 0) {
    while ($row_recent_orders = $result_recent_orders->fetch_assoc()) {
        $recent_orders[] = $row_recent_orders;
    }
}

// Modify query to get sales for all months from January to December
$sales_per_month_paid = array();
for ($month = 1; $month <= 12; $month++) {
    $monthStr = str_pad($month, 2, '0', STR_PAD_LEFT); // Add leading zero if necessary
    $monthYear = date('Y') . '-' . $monthStr;
    $sales_per_month_paid[$monthYear] = 0; // Initialize sales for the month
}

$sql_sales_per_month_paid = "SELECT DATE_FORMAT(o.OrderDate, '%Y-%m') AS month, SUM(o.TotalAmount) AS total_sales 
                            FROM orders o
                            WHERE o.PaymentStatus = 'Paid'
                            GROUP BY DATE_FORMAT(o.OrderDate, '%Y-%m')";
$result_sales_per_month_paid = $conn->query($sql_sales_per_month_paid);

while ($row_sales_per_month_paid = $result_sales_per_month_paid->fetch_assoc()) {
    $sales_per_month_paid[$row_sales_per_month_paid['month']] = $row_sales_per_month_paid['total_sales'];
}

// Sort the sales data by month
ksort($sales_per_month_paid);
$out_of_stock_products = array();
$sql_out_of_stock = "SELECT ProductName, Photo FROM products WHERE QuantityAvailable = 0";
$result_out_of_stock = $conn->query($sql_out_of_stock);
if ($result_out_of_stock->num_rows > 0) {
    while ($row = $result_out_of_stock->fetch_assoc()) {
        $out_of_stock_products[] = $row;
    }
}
$conn->close();
?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .home {
            padding: 20px;
            background-color: #ffffff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .dashboard-info {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
        }

        .info-box {
            border-radius: 5px;
            padding: 20px;
            flex-basis: calc(33.333% - 20px);
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: relative;
            min-width: 250px;
        }

        .info-box button {
            position: absolute;
            bottom: 10px;
            right: 10px;
            transform: translateX(-5%);
        }

        .dashboard-info .info-box h3 {
            color: #111;
            font-weight: 700;
            font-size: 20px;
        }

        .info-box p,
        .info-box ul li {
            font-size: 30px;
            margin: 0;
            color: white;
        }

        .orders-list {
            list-style: none;
            padding: 0;
        }

        .orders-list li {
            margin-bottom: 10px;
        }

        .admin-dashboard h3 {
            margin-top: 0;
            margin-bottom: .5rem;
            font-weight: 500;
            color: var(--bs-heading-color);
        }

        table {
            width: 100%;
            border-bottom: 1px solid #dee2e6;
            border-collapse: collapse;
            border-top: 1px solid #dee2e6;
        }
        tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    tr:hover {
        background-color: #f1f1f1;
    }
        .admin-dashboard td,
        .admin-dashboard th {
            margin: 0;
            font-size: 12px;
            padding: 10px;
            text-align: left;
        }

        .admin-dashboard th {
            background-color: #8fd19e;
        }

        .order-status-pending {
            color: orange;
        }

        .order-status-processing {
            color: blue;
        }

        .order-status-shipped {
            color: green;
        }

        .order-status-delivered {
            color: #888;
        }

        .payment-status-pending {
            color: orange;
        }

        .payment-status-paid {
            color: #888;
        }

        .orders-table-container {
            max-height: 300px;
            overflow-y: auto;
            border-bottom: 1px solid #dee2e6;
        }

        .admin-dashboard {
            width: 100%;
            border-bottom: 1px solid #dee2e6;
            border-collapse: collapse;
            margin-bottom: 0;
        }

        .summary-and-orders {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
        }

        .summary {
            width: 49%;
        }

        .orders {
            width: 49%;
        }

        .custom-modal-size {
            max-width: calc(100% - 30px);
            width: calc(100% - 30px);
            font-size: 10px;
        }

        .btn-close {
            border: none;
            background-color: transparent;
            font-size: 30px;
            font-weight: 700;
            color: lightcoral;
        }

        .btn-close:hover {
            color: red;
        }

        .view-all {
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            background-color: transparent;
            font-weight: 700;
            color: white;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
            text-align: left;
        }

        .modal-content {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            max-width: 600px;
            min-width: 200px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            transition: background-color 0.3s;
        }

        .modal-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .modal .admin-dashboard {
            width: 100%;
            border-bottom: 1px solid #dee2e6;
            border-collapse: collapse;
            border-top: 1px solid #dee2e6;
            margin-bottom: 0;
        }

        .modal h3 {
            /* font-weight: 700;
            color: var(--bs-heading-color);
            font-size: 16px;
            color: #555; */
        }

        .modal table {
            width: 100%;
            border-bottom: 1px solid #dee2e6;
            border-collapse: collapse;
            border-top: 1px solid #dee2e6;
        }

        .modal .admin-dashboard th {
            margin: 0;
            font-size: 13px;
            padding: 10px;
            text-align: left;
        }

        .modal .admin-dashboard td {
            padding: 8px;
            font-size: 12px;
            border-bottom: 1px solid #f4f4f4;
        }

        .modal .admin-dashboard th {
            background-color: #8fd19e;
        }

        .modal .orders-table-container {
            max-height: 380px;
            overflow-y: auto;
        }

        @media screen and (max-width: 768px) {
            .info-box {
                flex-basis: calc(100% - 20px);
                /* Two boxes per row on smaller screens */
            }

            .summary,
            .orders {
                width: 100%;
                /* Full width on smaller screens */
            }
        }
    </style>
</head>

<body>
    <?php include 'sidebar.php'; ?>
    <?php include 'graph.php'; ?>
    <section class="home">
        <div class="container-fluid">
            <div class="admin-dashboard">
                <h2>Dashboard</h2>
                <div class="dashboard-info">
                    <div class="info-box d-flex justify-content-between bg bg-primary mb-1">
                        <div>
                            <h3>Total Products</h3>
                            <p><i class="fa-solid fa-bag-shopping"></i> <strong><?php echo $total_products; ?></strong></p>
                        </div>
                        <button type="button" class="view-all   " data-bs-toggle="modal" data-bs-target="#viewAllProductsModal">View All</button>
                    </div>

                    <div class="info-box d-flex justify-content-between bg bg-success mb-1">
                        <div>
                            <h3>Registered Users</h3>
                            <p><i class="fa-solid fa-users"></i> <strong><?php echo $total_users; ?></strong></p>
                        </div>
                        <button type="button" class="view-all" data-bs-toggle="modal" data-bs-target="#viewAllUsersModal">View All</button>
                    </div>

                    <div class="info-box d-flex justify-content-between bg bg-danger mb-1">
                        <div>
                            <h3>Total Sales</h3>
                            <p><i class="fa-solid fa-peso-sign"></i> <strong><?php echo number_format($total_sales); ?></strong></p>
                        </div>
                        <button type="button" class="view-all" data-bs-toggle="modal" data-bs-target="#viewAllUsersModal"></button>
                    </div>
                </div>

                <div class="summary-and-orders mt-4">
                    <div class="summary border border-2 border-success-subtle border-start rounded bg bg-light p-2">
                        <div class="dashboard-summary">
                            <h4>Monthly Sales Report</h4>
                            <canvas id="summaryChart"></canvas>
                        </div>
                    </div>

                    <div class="orders">
                        <h3>Recent Orders</h3>
                        <div class="row">
                            <div style="overflow-x:auto;" class="orders-table-container col-12">
                                <table class="admin-dashboard">
                                    <thead>
                                        <tr>
                                            <th class>No.</th>
                                            <th>Customer Name</th>
                                            <th>Order Date</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $orderNumber = 1; // Initialize order number
                                        foreach ($recent_orders as $order) :
                                        ?>
                                            <tr>
                                                <td><?php echo $orderNumber; ?></td>
                                                <td><?php echo $order['CustomerName']; ?></td>
                                                <td><?php echo date("F j, Y", strtotime($order['OrderDate'])); ?></td>
                                                <td class="<?php echo 'order-status-' . strtolower(str_replace(' ', '-', $order['OrderStatus'])); ?>"><?php echo $order['OrderStatus']; ?></td>
                                            </tr>
                                        <?php
                                            $orderNumber++; // Increment order number for next iteration
                                        endforeach;
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <div class="modal fade" id="viewAllProductsModal" tabindex="-1" aria-labelledby="viewAllProductsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md custom-modal-size">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="viewAllProductsModalLabel">Total Products</h3>
                    <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal" aria-label="Close">
                        &times;</button>
                </div>
                <div class="modal-body orders-table-container">
                    <table class="table">
                        <thead class="admin-dashboard">
                            <tr>
                                <th>Product Name</th>
                                <th>Price</th>
                                <th style="text-align: center">Quantity</th>
                            </tr>
                        </thead>
                        <tbody class="admin-dashboard">
                            <?php
                            // Fetch products from the database
                            $sql_products = "SELECT * FROM products";
                            $result_products = $conn->query($sql_products);

                            if ($result_products->num_rows > 0) {
                                while ($row_product = $result_products->fetch_assoc()) {
                                    echo "<tr>";
                                    echo "<td>" . $row_product['ProductName'] . "</td>";
                                    echo "<td style='color: red;'>₱" . $row_product['Price'] . "</td>";
                                    echo "<td style='color: blue; text-align: center'>" . $row_product['QuantityAvailable'] . "</td>";

                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='3'>No products found</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="viewAllUsersModal" tabindex="-1" aria-labelledby="viewAllUsersModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md custom-modal-size">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="viewAllUsersModalLabel">Registered Users</h3>
                    <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal" aria-label="Close">&times;</button>
                </div>
                <div class="modal-body orders-table-container">
                    <table class="table">
                        <thead class="admin-dashboard">
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                            </tr>
                        </thead>
                        <tbody class="admin-dashboard">
                            <?php
                            // Fetch users from the database
                            $sql_users = "SELECT * FROM customers";
                            $result_users = $conn->query($sql_users);

                            if ($result_users->num_rows > 0) {
                                while ($row_user = $result_users->fetch_assoc()) {
                                    echo "<tr>";
                                    echo "<td>" . $row_user['Name'] . "</td>";
                                    echo "<td>" . $row_user['Email'] . "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='2'>No users found</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        var ctx = document.getElementById('summaryChart').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?php
                        // Generate an array of month names from January to December
                        $months = array('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec');
                        echo json_encode($months);
                        ?>,
                datasets: [{
                    backgroundColor: ["DodgerBlue", "DodgerBlue", "DodgerBlue", "DodgerBlue", "DodgerBlue", "DodgerBlue", "DodgerBlue", "DodgerBlue", "DodgerBlue", "DodgerBlue", "DodgerBlue", "DodgerBlue"],
                    data: <?php echo json_encode(array_values($sales_per_month_paid)); ?>
                }]
            },
            options: {
                legend: {
                    display: false
                },
                title: {
                    display: true,
                    text: "Monthly Sales (Paid)"
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
<script>
    document.addEventListener('DOMContentLoaded', (event) => {
        if (!('Notification' in window)) {
            alert('This browser does not support desktop notifications.');
        } else {
            function showNotification(product) {
                const title = 'Product Out of Stock';
                const options = {
                    body: `${product.ProductName} is out of stock.`,
                    icon: product.Photo,
                    data: {
                        url: 'management/products.php'
                    }
                };
                const notification = new Notification(title, options);
                notification.onclick = function(event) {
                    event.preventDefault();
                    window.location.href = notification.data.url;
                };
            }

            if (Notification.permission === 'granted') {
                <?php foreach ($out_of_stock_products as $product) : ?>
                    showNotification({
                        ProductName: "<?php echo $product['ProductName']; ?>",
                        Photo: "<?php echo $product['Photo']; ?>"
                    });
                <?php endforeach; ?>
            } else if (Notification.permission !== 'denied' || Notification.permission === 'default') {
                Notification.requestPermission().then(function(permission) {
                    if (permission === 'granted') {
                        <?php foreach ($out_of_stock_products as $product) : ?>
                            showNotification({
                                ProductName: "<?php echo $product['ProductName']; ?>",
                                Photo: "<?php echo $product['Photo']; ?>"
                            });
                        <?php endforeach; ?>
                    }
                });
            }
        }
    });
</script>

</html>