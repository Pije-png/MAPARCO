export declare const ASSET_CAMERA_SCAN: string;
export declare const ASSET_FILE_SCAN: string;
export declare const ASSET_INFO_ICON_16PX: string;
export declare const ASSET_CLOSE_ICON_16PX: string;
