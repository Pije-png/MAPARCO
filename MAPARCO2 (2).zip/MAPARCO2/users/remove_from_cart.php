<?php
// Include database connection
include('../connection.php');

// Check if productID is set and not empty
if (isset($_POST['productID']) && !empty($_POST['productID'])) {
    // Sanitize input to prevent SQL injection
    $productID = mysqli_real_escape_string($conn, $_POST['productID']);

    // Assuming you have a CustomerID, replace 1 with the actual CustomerID
    $customerID = 1;

    // Delete the item from the cart
    $sql = "DELETE FROM cart WHERE CustomerID = $customerID AND ProductID = $productID LIMIT 1";

    if ($conn->query($sql) === TRUE) {
        // Deletion successful
        echo "Item removed from cart successfully";
    } else {
        // Error in deletion
        echo "Error removing item from cart: " . $conn->error;
    }
} else {
    // ProductID not set or empty
    echo "Invalid product ID";
}

// Close database connection
$conn->close();
