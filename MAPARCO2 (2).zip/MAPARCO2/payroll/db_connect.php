<?php 

$conn= new mysqli('localhost','u131413745_us_maparco','KAMINARI2zero21','u131413745_maparco')or die("Could not connect to mysql".mysqli_error($con));
